const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');  // Import cors middleware


dotenv.config();

// Create an Express app
const app = express();
app.use(bodyParser.json());

// Mock database (users array) - storing plain text passwords
app.use(cors({ origin: 'http://localhost:5173' })); // Allow requests from your frontend's URL

const users = [
  {
    id: 1,
    username: 'user@example.com',
    password: 'password123',  // Plain text password
  }
];
// Mock data for products
const products = [
    {
      id: 1,
      name: 'Product 1',
      description: 'This is a description for Product 1',
      price: 29.99,
      image: 'https://via.placeholder.com/150', // Placeholder image for the product
    },
    {
      id: 2,
      name: 'Product 2',
      description: 'This is a description for Product 2',
      price: 49.99,
      image: 'https://via.placeholder.com/150',
    },
    {
      id: 3,
      name: 'Product 3',
      description: 'This is a description for Product 3',
      price: 19.99,
      image: 'https://via.placeholder.com/150',
    },
  ];
  // Mock data for carts and orders
  let carts = {};
  let cartId = 1;
  let orders = [
    { id: 1, cart_id: 1, status: 'completed', total: 99.99 }, // An example completed order
  ];
  
// POST /products route to get the product list
app.get('/products', (req, res) => {
    res.json(products);
  });
    

// POST /users/login route to handle login
app.post('/users/login', (req, res) => {
  const { username, password } = req.body;
// ADD to cart
// Example route for adding an item to the cart

app.post('/carts', (req, res) => {
    const { item_id } = req.body;  // Extract item_id from request body
    if (!item_id) {
      return res.status(400).json({ error: 'Item ID is required' });
    }
  
    // Check if cart exists, if not create it
    if (!carts[cartId]) {
      carts[cartId] = { id: cartId, items: [] };
    }
  
    // Add the item to the cart
    const existingItem = carts[cartId].items.find(item => item.id === item_id);
  
    if (existingItem) {
      // If item already exists in cart, increase its quantity
      existingItem.quantity += 1;
    } else {
      // If it's a new item, add it to the cart
      carts[cartId].items.push({ id: item_id, quantity: 1 });
    }
  
    // Respond with the updated cart
    res.status(200).json(carts[cartId]);
  });

  // Find user in the "database"
  const user = users.find(u => u.username === username);

  // If user doesn't exist, return error
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Compare the plain password with the stored password
  if (password !== user.password) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Generate a JWT token for the user
  const token = jwt.sign(
    { id: user.id, username: user.username },
    process.env.JWT_SECRET,  // Add your JWT secret in .env file
    { expiresIn: '1h' }
  );

  // Return the token and user details
  res.json({ token, user: { id: user.id, username: user.username } });
});

// Start the server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
